import pandas as pd

def recommend_crops(ph, climate):
    # Load crop data
    crop_data = pd.read_csv("data/crop_data.csv")
    
    # Filter crops based on pH and climate suitability
    suitable_crops = crop_data[(crop_data['min_ph'] <= ph) & (crop_data['max_ph'] >= ph)]
    suitable_crops = suitable_crops[suitable_crops['climate'].str.contains(climate, case=False)]
    
    return suitable_crops['crop_name'].tolist()