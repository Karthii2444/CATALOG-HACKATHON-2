def recommend_soil_treatment(ph, moisture):
    recommendations = []

    if ph < 6.0:
        recommendations.append("Add lime to increase the pH.")
    elif ph > 7.5:
        recommendations.append("Add sulfur to decrease the pH.")
    else:
        recommendations.append("pH level is optimal.")
    
    # Moisture recommendation
    if moisture < 30:
        recommendations.append("Increase irrigation to raise soil moisture.")
    elif moisture > 60:
        recommendations.append("Reduce irrigation to lower soil moisture.")
    else:
        recommendations.append("Moisture level is optimal.")
    
    return recommendations