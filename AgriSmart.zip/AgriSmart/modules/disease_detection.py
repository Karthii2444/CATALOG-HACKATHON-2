import pandas as pd

def detect_disease(symptoms):
    # Load disease data
    disease_data = pd.read_csv("data/disease_data.csv")
    
    # Filter diseases based on symptoms
    detected_diseases = disease_data[disease_data['symptoms'].str.contains(symptoms, case=False)]
    
    return detected_diseases['disease_name'].tolist()