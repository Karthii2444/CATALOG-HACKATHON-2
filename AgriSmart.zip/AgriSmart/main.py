from modules.soil_management import recommend_soil_treatment
from modules.crop_selection import recommend_crops
from modules.disease_detection import detect_disease
from utils import get_input

def main():
    print("Welcome to the Crop and Soil Management System")

    # Get soil parameters from user
    ph = get_input("Enter soil pH: ")
    moisture = get_input("Enter soil moisture level (percentage): ")
    climate = input("Enter climate (hot/cold/moderate): ").lower()
    
    # Soil Management Recommendations
    soil_recommendations = recommend_soil_treatment(ph, moisture)
    print("\nSoil Management Recommendations:")
    for recommendation in soil_recommendations:
        print(f"- {recommendation}")
    
    # Crop Selection Recommendations
    crop_recommendations = recommend_crops(ph, climate)
    print("\nBest Crops to Plant:")
    for crop in crop_recommendations:
        print(f"- {crop}")
    
    # Disease Detection (Optional)
    detect_disease_prompt = input("\nDo you want to detect plant diseases? (yes/no): ").lower()
    if detect_disease_prompt == 'yes':
        symptoms = input("Enter plant symptoms (e.g., leaf spots, yellowing of leaves): ").lower()
        disease_recommendations = detect_disease(symptoms)
        print("\nPossible Diseases and Recommendations:")
        for disease in disease_recommendations:
            print(f"- {disease}")
    
    print("\nThank you for using the Crop and Soil Management System!")

if __name__ == "__main__":
    main()